package aula01;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.mysql.jdbc.PreparedStatement;

public class exercicio01 {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
		String driver = "com.mysql.jdbc.Driver";
		
		Class.forName(driver);
		
		String url = "jdbc:mysql://localhost3306/";
		String user = "root";
		String password = "";
		
		Connection conn = DriverManager.getConnection(url , user , password);
		
		String sql = "CREATE DATABASE IF NOT EXISTS BDaula1;";
		PreparedStatement stmt = (PreparedStatement) conn.prepareStatement(sql);
		stmt.execute();
		
		sql = "USE BDaula1;";
		stmt = (PreparedStatement) conn.prepareStatement(sql);
		stmt.execute();
		
		sql = "CREATE TABLE IF NOT EXISTS alunos (id int , nome varchar(50) , idade int);";
		stmt = (PreparedStatement) conn.prepareStatement(sql);
		stmt.execute();
		
		sql = "CREATE TABLE IF NOT EXISTS turmas (id int , turma varchar(10) , sala int);";
		stmt = (PreparedStatement) conn.prepareStatement(sql);
		stmt.execute();
		
		sql = "CREATE TABLE IF NOT EXISTS materias (id int , nome varchar(50) , professor varchar(50));";
		stmt = (PreparedStatement) conn.prepareStatement(sql);
		stmt.execute();
		
		sql = "DROP TABLE alunos;";
		stmt = (PreparedStatement) conn.prepareStatement(sql);
		stmt.execute();
		
		sql = "DROP TABLE turmas;";
		stmt = (PreparedStatement) conn.prepareStatement(sql);
		stmt.execute();
		
		sql = "DROP TABLE materias;";
		stmt = (PreparedStatement) conn.prepareStatement(sql);
		stmt.execute();
		
		sql = "DROP DATABASE alunos;";
		stmt = (PreparedStatement) conn.prepareStatement(sql);
		stmt.execute();
	}

}
