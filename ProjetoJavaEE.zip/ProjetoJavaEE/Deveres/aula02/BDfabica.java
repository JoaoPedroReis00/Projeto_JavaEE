package aula02;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import com.mysql.jdbc.PreparedStatement;

public class BDfabica {

	private static Connection conn = null;
	
	public static void main(String[] args) {
		
		Scanner ler = new Scanner(System.in);
		
		Boolean aux = false;
		
		canectarSQL();
		
		String op = null;
		
		do {
			
			op = "";
			aux = false;
			
			System.out.println("___________________________________________________________\n"+
			"Menu:\n\n"+
			"Digite 1 para criar um Banco de Dados, chamado �BDFabrica�.\n" + 
			"Digite 2 para criar uma tabela chamado �Carros� .\n" + 
			"Digite 3 para apagar o Banco de Dados �BDFabrica�\n" + 
			"Digite 4 para apagar a tabela �Carros�\r\n" + 
			"Digite 5 para inserir um registro na tabela �Carros�.\n" + 
			"Digite 6 para localizar um registro na tabela �Carros�.\n" + 
			"Digite 7 para deletar um registro na tabela �Carros�.\n" + 
			"Digite 8 para exibir a lista de todos os carros cadastrados.\n" + 
			"Digite �s� para sair.");
			op = ler.nextLine();
			
			switch (op) {
			
			case "1":	
				
				criar("DATABASE");
				
				break;
				
			case "2":
				
				criar("TABLE");	
				
				break;
			
			case "3":
				
				excluir("DATABASE");
				
				break;
				
			case "4":
				
				excluir("TABLE");
				
				break;
				
			case "5":
				
				System.out.println("Digite o nome do carro:");
				String nome = ler.nextLine();
					
				System.out.println("Digite o ano do carro:");
				String ano = ler.nextLine();
					
				System.out.println("Digite a marca do carro:");
				String marca = ler.nextLine();
					
				inserir(nome , ano , marca);
				
				break;
				
			case "6":
				
				System.out.println("Digite o n�mero de identifica��o do autom�vel desejado.");
				String id = ler.nextLine();
					
				localizar(id);
				
				break;
				
			case "7":
				
				System.out.println("Digite o nome do autom�vel � ser deletado.");
				String nome1 = ler.nextLine();
					
				deletar(nome1);
				
				break;
				
			case "8":
				
				lista();
				
				break;
			
			case "s":
				
				sair();
				
				aux = true;
				
				break;
					
			default:
				
				System.out.println("A Op��o digitada � inv�lida.");
				break;
			}
			
		}while(aux == false);
		
		ler.close();
	}
	
	public static void canectarSQL() {
		
		try {
			
			String driver = "com.mysql.jdbc.Driver";
			Class.forName(driver);
			
			String url = "jdbc:mysql://localhost";
			String name = "root";
			String password = "";
			
			conn = DriverManager.getConnection(url,name,password);
			
			if(conn != null) {
				
				System.out.println("Conectando...");
				
			}else {
				
				System.out.println("Erro na conex�o com o Banco de Dados.");
			}
		} catch (SQLException e) {
			
			System.out.println("Erro ao se conectatar com o Banco de Dados.\nErro 1: "+e.toString());
			
		} catch (ClassNotFoundException e2) {
			
			System.out.println("O Driver n�o foi encontrado. \nErro 2: "+e2.toString());
			
		} catch (Exception e3) {
			
			System.out.println("Erro ao se conectatar com o Banco de Dados.\nErro 3: "+e3.toString());
		}
	}
	
	public static void criar(String aux) {
		
		try {
			
			if(conn != null) {
				
				if(aux == "DATABASE") {
					
					String sql = "CREATE DATABASE IF NOT EXISTS BDFabrica;";
					PreparedStatement stmt = (PreparedStatement) conn.prepareStatement(sql);
					stmt.execute();
					
					System.out.println("Banco de Dados criado com sucesso.");
					
				}else {
					
					String sql = "USE BDFabrica;";
					PreparedStatement stmt = (PreparedStatement) conn.prepareStatement(sql);
					stmt.execute();
					
					sql = "CREATE TABLE IF NOT EXISTS carros (id int PRIMARY KEY AUTO_INCREMENT , nome varchar(50) , ano int , marca varchar(50));";
					stmt = (PreparedStatement) conn.prepareStatement(sql);
					stmt.execute();
					
					System.out.println("Tabela criado com sucesso.");
				}
			}
		}catch (SQLException e) {
			
			System.out.println("N�o foi poss�vel criar a "+aux+".\nErro : "+e.toString());
		}
	}
	
	public static void excluir(String aux) {
		
		try {
			
			if(conn != null) {
				
				if(aux == "DATABASE") {
					
					String sql = "DROP DATABASE IF EXISTS BDFabrica;";
					PreparedStatement stmt = (PreparedStatement) conn.prepareStatement(sql);
					stmt.execute();
					
					System.out.println("Banco de Dados excluido com sucesso.");
					
				}else {
					
					String sql = "USE BDFabrica;";
					PreparedStatement stmt = (PreparedStatement) conn.prepareStatement(sql);
					stmt.execute();
					
					sql = "DROP TABLE IF EXISTS carros;";
					stmt = (PreparedStatement) conn.prepareStatement(sql);
					stmt.execute();
					
					System.out.println("Tabela excluido com sucesso.");
				}
			}
		}catch (SQLException e) {
			
			System.out.println("Erro ao deletar "+aux+". Erro: "+e.toString());
		}
	}
	
	public static void inserir(String nome , String ano , String marca) {
		
		try {
			
			if(conn != null) {
				
				
				String sql = "USE BDFabrica";
				PreparedStatement stmt = (PreparedStatement) conn.prepareStatement(sql);
				stmt.execute();
				
				sql = "INSERT INTO carros (nome , ano , marca) VALUES (\'"+nome+"\' , "+ano+" , \'"+marca+"\')";
				stmt = (PreparedStatement) conn.prepareStatement(sql);
				stmt.executeUpdate();
				
				System.out.println("Cadastro do autom�vel efetuado com sucesso.");
			}
		}catch (SQLException e) {
			
			System.out.println("Tabela carros n�o encontrada. Erro: "+e.toString());
		}
	}
	
	public static void localizar(String id) {
		
		try {
			
			if(conn != null) {
				
				String sql = "USE BDFabrica;";
				PreparedStatement stmt = (PreparedStatement) conn.prepareStatement(sql);
				stmt.execute();
				
				sql = "SELECT nome , ano , marca FROM carros WHERE id = "+id+";";
				stmt = (PreparedStatement) conn.prepareStatement(sql);
				ResultSet resultado = stmt.executeQuery();
				
				boolean aux = true;
				
				while(resultado.next()) {
					
					aux = false;
					System.out.println("Nome : "+resultado.getString(1)+"\nAno : "+resultado.getInt(2)+"\nMarca : "+resultado.getString(3));
				}
				
				if(aux) {
					
					System.out.println("Autom�vel n�o encontrado.");
				}
			}
		}catch (SQLException e) {
			
			System.out.println("Tabela carros n�o encontrada. Erro: "+e.toString());
		}
	}
	
	public static void deletar(String nome) {
		
		try {
			
			if(conn != null) {
				
				String sql = "USE BDFabrica;";
				PreparedStatement stmt = (PreparedStatement) conn.prepareStatement(sql);
				stmt.execute();
				
				sql = "DELETE FROM carros WHERE nome = "+nome+";";
				stmt = (PreparedStatement) conn.prepareStatement(sql);
				int resultado = stmt.executeUpdate();
				
				if(resultado == 0) {
					
					System.out.println("O cadastro informado n�o foi encontrado.");
					
				}else {
					
					System.out.println("Cadastro deletado com sucesso.");
				}
			}
		}catch (SQLException e) {
			
			System.out.println("Tabela carros n�o encontrada. Erro: "+e.toString());
		}
	}
	
	public static void lista() {
		
		try {
			
			if(conn != null) {
				
				String sql = "USE BDFabrica;";
				PreparedStatement stmt = (PreparedStatement) conn.prepareStatement(sql);
				stmt.execute();
				
				sql = "SELECT COUNT(*) FROM carros;";
				stmt = (PreparedStatement) conn.prepareStatement(sql);
				ResultSet resultado = stmt.executeQuery();
				
				boolean aux = true;
				
				while(resultado.next()) {
					
					aux = false;
					
					int id = resultado.getInt(1);
					String nome = resultado.getString(2);
					int ano = resultado.getInt(3);
					String marca = resultado.getString(4);
					
					System.out.println("Id: "+id+" | Nome: "+nome+" | Ano: "+ano+" | Marca: "+marca+";");
					
					
				}
				
				if(aux) {
					
					System.out.println("Nenhum cadastro encontrado.");
					
				}
			}
		}catch (SQLException e) {
			
			System.out.println("Tabela carros n�o encontrada. Erro: "+e.toString());
		}
	}
	
	public static void sair() {
		
		try {
			
			String sql = "DROP DATABASE IF EXISTS BDFabrica";
			PreparedStatement stmt = (PreparedStatement) conn.prepareStatement(sql);
			stmt.execute();
			
			conn.close();
			
			System.out.println("Fim do Programa.");
			
		}catch (Exception e) {
			
			System.out.println("Erro ao sair do programa. Erro: "+e.toString());
		}
	}
}
