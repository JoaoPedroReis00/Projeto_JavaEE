package aula03;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;
import java.util.Vector;

import com.mysql.jdbc.PreparedStatement;

import aula02.ConexaoSQL;

public class BDBiblioteca {
	
	private static Connection conn = null;

	public static void main(String[] args) {
		
		Scanner ler = new Scanner(System.in);
		
		int op = 0;
		
		do {
			
			op = 0;
			
			System.out.println("___________________________________________________________\n"+
			"Menu:\n\n"+
			"Digite 1 para criar um Banco de Dados, chamado \"BDBiblioteca\".\n" + 
			"Digite 2 para deletar o Banco de Dados BDBiblioteca .\n" + 
			"Digite 3 para criar uma tabela chamada \"livros\"\n" + 
			"Digite 4 para criar uma tabela chamada \"Socios\".\n" + 
			"Digite 5 para deletar a tabela Livros ou Socios.\n" + 
			"Digite 6 para inserir um cadastro na tabela Livros.\n" + 
			"Digite 7 para inserir um cadastro na tabela Socios.\n" + 
			"Digite 8 para localizar um livro.\n" + 
			"Digite 9 para deletar um livro ou s�cio."+
			"Digite 10 para exibir a quantidade de livros cadastrados."+
			"Digite 11 para exibir a quantidade de s�cios cadastrados."+
			"Digite 12 para sair.");
			op = ler.nextInt();
			
			switch (op) {
			
			case 1:{	
				
				if(criarBD("BDBiblioteca")) {
				
					System.out.println("Banco de Dados criado com sucesso.");
				}
				
				break;
			}
			
			case 2:{
				
				if(deletarBD("BDBiblioteca")) {
					
					System.out.println("Banco de Dados deletado com sucesso.");
				}	
				break;
			}
			
			case 3:{
				
				if(criarTable("livros (id int PRIMARY KEY AUTO_INCREMENT , nome varchar(100) , autor varchar(50) , nr_pag int);", "BDBiblioteca")) {
					
					System.out.println("Tabela criada com sucesso.");
				}
				break;
			}
			
			case 4:{
				
				if(criarTable("socios (id int PRIMARY KEY AUTO_INCREMENT , nome varchar(100) , idade int , sexo varchar(1));", "BDBiblioteca")) {
					
					System.out.println("Tabela criada com sucesso.");
				}
				break;
			}
			
			case 5:{
				
				String tabelas = mostrarTables("BDBiblioteca");
				
				if(tabelas.isEmpty()) {
					
					System.out.println("Nenhuma tabela cadastrada.");
					
				}else {
					
					if(tabelas.equals("erro")) {
					
					}else {
						
						String t[] = tabelas.split(" ");
						
						for(int i = 0 ; i<t.length ; i++) {
							
							System.out.println("Digite "+(i+1)+" para deletar "+t[i]);
							int op2 = ler.nextInt();
							
							if(deletarTable(t[op2-1] , "BDBiblioteca")) {
								
								System.out.println("banco de Dados deletado com sucesso.");
							}
						}
					}
				}
				break;
			}
			
			case 6:{
				
				System.out.println("Digite o nome do livro:");
				String nome = ler.nextLine();
				
				System.out.println("Digite o nome do autor do livro:");
				String autor = ler.nextLine();
				
				System.out.println("Digite o n�mero de p�ginas:");
				String nrPag = ler.nextLine();
				
				if(inserirTable("BDBiblioteca" , "livros" , "\'"+nome+"\' , \'"+autor+"\' , "+nrPag)) {
					
					System.out.println("livro cadastrado.");
				}
				break;
			}
			
			case 7:{
				
				System.out.println("Digite o nome do s�cio:");
				String nome = ler.nextLine();
				
				System.out.println("Digite a idade do s�cio:");
				String idade = ler.nextLine();
				
				System.out.println("Digite o n�mero de p�ginas:");
				String sexo = ler.nextLine();
				
				if(inserirTable("BDBiblioteca" , "socios" , "\'"+nome+"\' , "+idade+" , \'"+sexo+"\'")) {
					
					System.out.println("livro cadastrado.");
				}
				break;
			}
			
			case 8:{
				
				System.out.println("Digite 1 para localizar livros\n"+
				"Digite 2 para localizar s�cios");
				int op2 = ler.nextInt();
				
				int aux2 = 0;
				
				String nome = null;
				
				if(op2 == 1) {
					
					System.out.println("Digite o nome do livro procurado.");
					nome = ler.nextLine();
					
					aux2 = localizar("BDBiblioteca", "livros" , nome);
					
				}else {
					
					if(op2 == 2) {
						
						System.out.println("Digite o nome do s�cio procurado.");
						nome = ler.nextLine();
						
						aux2 = localizar("BDBiblioteca", "socios" , nome);
						
					}else {
						
						System.out.println("Op��o inv�lida");
					}
				}
				
				if(aux2 == 0) {
					
					System.out.println("Nenhum cadastro encontrado.");
				}
				break;
			}
			
			case 9:{
				
				System.out.println("Digite 1 para localizar livros\n"+
				"Digite 2 para localizar s�cios");
				int op2 = ler.nextInt();
				
				int aux = 0;
				
				String nome = null;
				
				int id = 0;
				
				if(op2 == 1) {
					
					System.out.println("Digite o nome do livro procurado.");
					nome = ler.nextLine();
					
					aux = localizar("BDBiblioteca", "livros" , nome);
					
					if(aux > 0) {
						
						System.out.println("Digite o ID do livro que voc� deseja deletar:");
						id = ler.nextInt();
						
						if(deletar("BDBiblioteca", "livros", id)) {
							
							System.out.println("Cadastro deletado.");
						}
					}
					
				}else {
					
					if(op2 == 2) {
						
						System.out.println("Digite o nome do s�cio procurado.");
						nome = ler.nextLine();
						
						aux = localizar("BDBiblioteca", "socios" , nome);
						
						if(aux > 0) {
							
							System.out.println("Digite o ID do s�cio que voc� deseja deletar:");
							id = ler.nextInt();
							
							if(deletar("BDBiblioteca", "socios", id)) {
								
								System.out.println("Cadastro deletado.");
							}
						}
						
					}else {
						
						System.out.println("Op��o inv�lida");
					}
				}
				
				if(aux == 0) {
					
					System.out.println("Nenhum cadastro encontrado.");
					
				}
				break;	
			}
			
			case 10:{
				
				int quant = quantidade("BDBiblioteca", "livros");
				
				if(quant == 0) {
					
					System.out.println("Nenhum livro cadastrado.");
					
				}else {
					
					if(quant > 0) {
						
						System.out.println(quant+" livros cadastrados.");
					}
				}
				break;
			}
			
			case 11:{
				
				int quant = quantidade("BDBiblioteca", "socios");
				
				if(quant == 0) {
					
					System.out.println("Nenhum s�cio cadastrado.");
					
				}else {
					
					if(quant > 0) {
						
						System.out.println(quant+" s�cios cadastrados.");
					}
				}
				break;
			}
			
			case 12:{
				
				sair();
				
				break;
			}
			default:
				
				System.out.println("A Op��o digitada � inv�lida.");
				break;
			}
		}while(op != 12);
		
		ler.close();
	}
	
	public static boolean conectarSQL() {
		
		try {
			
			String driver = "com.mysql.jdbc.Driver";
			Class.forName(driver);
			
			String url = "jdbc:mysql://localhost";
			String name = "root";
			String password = "";
			
			conn = DriverManager.getConnection(url,name,password);
			
			if(conn != null) {
				
				System.out.println("Conectando...");
				
				return true;
				
			}else {
				
				System.out.println("Erro na conex�o com o Banco de Dados.");
			}
		} catch (SQLException e) {
			
			System.err.println("N�o foi poss�vel se conectar ao Banco de Dados.\nErro 1: "+e.toString());
			
		} catch (ClassNotFoundException e2) {
			
			System.err.println("O Driver n�o foi encontrado. \nErro 2: "+e2.toString());
			
		} catch (Exception e3) {
			
			System.err.println("Erro 3: "+e3.toString());
		}
		
		return false;
	}
	
	public static boolean criarBD(String bd) {
		
		try {
			
			if(conectarSQL()) {
					
				String sql = "CREATE DATABASE IF NOT EXISTS "+bd+";";
				PreparedStatement stmt = (PreparedStatement) conn.prepareStatement(sql);
				stmt.execute();
					
				return true;	
			}
		}catch (SQLException e) {
			
			System.err.println("N�o foi poss�vel criar o Banco de Dados "+bd+".\nErro : "+e.toString());
		}
		return false;
	}
	
	public static boolean criarTable(String table , String bd) {
		
		try {
			
			if(conectarSQL()) {
				
				String sql = "USE "+bd+";";
				PreparedStatement stmt = (PreparedStatement) conn.prepareStatement(sql);
				stmt.execute();
				
				sql = "CREATE TABLE IF NOT EXISTS "+table+";";
				stmt = (PreparedStatement) conn.prepareStatement(sql);
				stmt.execute();
				
				return true;
			}
			
		}catch (SQLException e) {
			
			System.err.println("N�o foi poss�vel criar a Tabela "+table+".\nErro : "+e.toString());
		}
		return false;
	}
	
	public static boolean deletarBD(String bd) {
		
		try {
			
			if(conectarSQL()) {
				
				String sql = "DROP DATABASE IF EXISTS "+bd+";";
				PreparedStatement stmt = (PreparedStatement) conn.prepareStatement(sql);
				stmt.execute();
				
				return true;
			}
		}catch (SQLException e) {
			
			System.err.println("N�o foi poss�vel deletar o Banco de Dados "+bd+";");
		}
		return false;
	}
	
	public static String mostrarTables(String bd) {
		
		try {
			
			if(conectarSQL()) {
				
				String sql = "USE "+bd+";";
				PreparedStatement stmt = (PreparedStatement) conn.prepareStatement(sql);
				stmt.execute();
				
				sql = "SHOW TABLES;";
				stmt = (PreparedStatement) conn.prepareStatement(sql);
				ResultSet tabelas = stmt.executeQuery();
				
				boolean aux = false;
				
				int i = 1;
				
				String retorno = "";
				
				while(tabelas.next()) {
					
					aux = true;
					
					retorno += tabelas.getString(i)+" ";
				
					i++;
				}
				
				if(aux) {
					
					retorno = retorno.trim();
					
					return retorno;
					
				}else {
					
					return null;
				}
			}
			
		}catch (SQLException e) {
			
			System.err.println("N�o foi poss�vel se mostrar as Tabelas \n Erro: "+e.toString());
		}
		
		return "erro";
	}
	
	public static boolean deletarTable(String table , String bd) {
		
		try {
			
			if(conectarSQL()) {
				
				String sql = "USE "+bd+";";
				PreparedStatement stmt = (PreparedStatement) conn.prepareStatement(sql);
				stmt.execute();
				
				sql = "DROP TABLE IF EXISTS "+table+";";
				stmt = (PreparedStatement) conn.prepareStatement(sql);
				stmt.execute();
				
				return true;
			}
			
		}catch (SQLException e) {
			
			System.err.println("N�o foi poss�vel deletar a Tabela "+table+". \nErro: "+e.toString());
		}
		return false;
	}
	
	public static boolean inserirTable(String bd , String table , String valores) {
		
		try {
			
			if(conectarSQL()) {
				
				String sql = "USE "+bd+";";
				PreparedStatement stmt = (PreparedStatement) conn.prepareStatement(sql);
				stmt.execute();
				
				sql = "INSERT INTO "+table+" VALUES ("+valores+");";
				stmt = (PreparedStatement) conn.prepareStatement(sql);
				stmt.execute();
				
				return true;
			}
		}catch(SQLException e) {
			
			System.err.println("N�o foi poss�vel inserir as informa��es.\nErro: "+e.toString());
		}
		return false;
	}
	
	public static int localizar(String bd , String table , String nome) {
		
		try {
			
			if(conectarSQL()) {
				
				String sql = "USE "+bd+";";
				PreparedStatement stmt = (PreparedStatement) conn.prepareStatement(sql);
				stmt.execute();
				
				sql = "SELECT * FROM "+table+" WHERE nome LIKE ?;";
				stmt.setString(1, "%"+nome+"%");
				stmt = (PreparedStatement) conn.prepareStatement(sql);
				ResultSet resultado = stmt.executeQuery();
				
				int aux = 0;
				
				while(resultado.next()) {
					
					aux++;
					
					if(table.equals("livros")) {
						
						System.out.println("ID: "+resultado.getInt(1)+" | Nome: "+resultado.getString(2)+" | Autor: "+resultado.getString(3)+" | N�mero de P�ginas: "+resultado.getInt(4));
						
					}else {
						
						System.out.println("ID: "+resultado.getInt(1)+" | Nome: "+resultado.getString(2)+" | Idade: "+resultado.getInt(3)+" | Sexo: "+resultado.getString(4));
					}
				}
			}
		}catch (SQLException e) {

			System.err.println("N�o foi poss�vel localizar o cadastro. \nErro: "+e.toString());
		}
		return -1;
	}
	
	public static boolean deletar(String bd , String table , int id) {
		
		try {
			
			if(conectarSQL()) {
				
				String sql = "USE "+bd+";";
				PreparedStatement stmt = (PreparedStatement) conn.prepareStatement(sql);
				stmt.execute();
				
				sql = "DELETE FROM "+table+" WHERE id = "+id+";";
				stmt = (PreparedStatement) conn.prepareStatement(sql);
				stmt.executeUpdate();
				
				return true;
			}
			
		}catch (SQLException e) {

			System.err.println("N�o foi poss�vel deletar o cadastro. \nErro: "+e.toString());
		}
		
	return false;
	}
	
	public static int quantidade(String bd , String table) {
		
		try {
			
			if(conectarSQL()) {
				
				String sql = "USE "+bd+";";
				PreparedStatement stmt = (PreparedStatement) conn.prepareStatement(sql);
				stmt.execute();
				
				sql = "SELECT * FROM "+table+";";
				stmt = (PreparedStatement) conn.prepareStatement(sql);
				ResultSet resultado = stmt.executeQuery();
				
				int aux = 0;
				
				while(resultado.next()) {
					
					aux++;
					
				}
				return aux;
				
			}
		}catch (SQLException e) {
			
			System.err.println("N�o foi poss�vel exibir os resultados");
		}
		return -1;
	}
	
	public static void sair() {
		
		try {
			
			if(conectarSQL()) {
				
				conn.close();
				
				System.out.println("Fim do Programa.");
			}
			
		}catch(Exception e) {
			
			System.err.println("Erro ao sair. \nErro: "+e.toString());
		}
	}
}
