package aula02;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.mysql.jdbc.PreparedStatement;

public class Ex03 {

	public void main(String[] args) throws ClassNotFoundException, SQLException {
		
String driver = "com.mysql.jdbc.Driver";
		
		Class.forName(driver);
		
		String url = "jdbc:mysql://localhost:3306/bdstep";
		String user = "root";
		String password = "";
		
		Connection conn = DriverManager.getConnection(url, user, password);
		
		String sql = "INSERT INTO aluno (nome , cidade , data_nasc , uf) VALUES (? , ? , ? , ?)";
		
		PreparedStatement stmt = (PreparedStatement) conn.prepareStatement(sql);
		
		stmt.setString(1, "Raquel Lima");
		stmt.setString(2, "S�o Paulo");
		stmt.setString(3, "2000-11-20");
		stmt.setString(4, "SP");
		
		stmt.executeUpdate();
		
	}
}
