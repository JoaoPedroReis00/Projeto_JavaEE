package aula02;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.mysql.jdbc.PreparedStatement;

public class Ex01 {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
		String driver = "com.mysql.jdbc.Driver";
		
		Class.forName(driver);
		
		String url = "jdbc:mysql://localhost:3306/bdhotel";
		String user = "root";
		String password = "";
		
		Connection conn = DriverManager.getConnection(url, user, password);
		
		String sql = "SELECT id , modelo , ano , placa FROM carros;";
		PreparedStatement stmt = (PreparedStatement) conn.prepareStatement(sql);
		
		ResultSet resultado = stmt.executeQuery();
		
		while(resultado.next()) {
			
			System.out.println("ID: " + resultado.getInt("id") + ", Modelo: " + resultado.getString("modelo") + ", Ano: " + resultado.getInt("ano") + ", Placa: " + resultado.getString("placa"));
		}
		
		conn.close();
	}
}