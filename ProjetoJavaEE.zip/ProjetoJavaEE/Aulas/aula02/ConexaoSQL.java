package aula02;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.mysql.jdbc.PreparedStatement;

public class ConexaoSQL {

	private Connection conn = null;
	
	public void canectarBD() {
		
		try {
			
			String driver = "com.mysql.jdbc.Driver";
			Class.forName(driver);
			
			String url = "jdbc:mysql://localhost";
			String name = "root";
			String password = "";
			
			conn = DriverManager.getConnection(url,name,password);
			
			if(conn != null) {
				
				System.out.println("Conectando...");
				
			}else {
				
				System.out.println("Erro na conex�o com o Banco de Dados.");
			}
		} catch (SQLException e) {
			
			System.out.println("Banco de Dados n�o conectado.\nErro 1: "+e.toString());
			
		} catch (ClassNotFoundException e2) {
			
			System.out.println("O Driver n�o encontrado. \nErro 2: "+e2.toString());
			
		} catch (Exception e3) {
			
			System.out.println("Erro ao se conectatar com o Banco de Dados \nErro 3: "+e3.toString());
		}
	}
	
	public void close() {
		
		try {
			
			if(conn != null) {
				
				conn.close();
			}
		}catch(SQLException e) {
			
			System.out.println("Erro ao fecha conex�o");
		}
	}
	
	public void consultarBD(String sql) {
		
		try {
			
			if(conn != null) {
				
				PreparedStatement stmt = (PreparedStatement) conn.prepareStatement(sql);
				
			}
		}catch (Exception e) {
			
		}
	}
}
