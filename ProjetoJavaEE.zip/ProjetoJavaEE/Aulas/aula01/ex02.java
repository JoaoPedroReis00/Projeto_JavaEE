package aula01;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.mysql.jdbc.PreparedStatement;

public class ex02 {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
		String driver = "com.mysql.jdbc.Driver";
		
		Class.forName(driver);
		
		String url = "jdbc:mysql://localhost:3306/bdhotel";
		String user = "root";
		String password = "";
		
		Connection conn = DriverManager.getConnection(url, user, password);
		
		String sql = "SELECT id , modelo , ano , placa FROM carros WHERE id = 1";
		PreparedStatement stmt = (PreparedStatement) conn.prepareStatement(sql);
		
		ResultSet resultado = stmt.executeQuery();
		
		boolean aux = false;
		
		while(resultado.next()) {
			
			aux = true;
				
			System.out.println("ID: " + resultado.getInt("id") + ", Modelo: " + resultado.getString("modelo") + ", Ano: " + resultado.getInt("ano") + ", Placa: " + resultado.getString("placa"));
		}
		
		if(aux == false) {
			
			System.out.println("Modelo n�o encontrado");
		}
	}
}
