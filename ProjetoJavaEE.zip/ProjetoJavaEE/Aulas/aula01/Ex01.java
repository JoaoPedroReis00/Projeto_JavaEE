package aula01;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.mysql.jdbc.PreparedStatement;

public class Ex01 {

	public static void main(String[] args) throws ClassNotFoundException, SQLException{
		
		String driver = "com.mysql.jdbc.Driver";
		
		Class.forName(driver);
		
		String url = "jdbc:mysql://localhost:3306/";
		String user = "root";
		String password = "";
		
		Connection conn = DriverManager.getConnection(url, user, password);
		
		String sql = "create database if not exists BDaula1;";
		PreparedStatement stmt = (PreparedStatement) conn.prepareStatement(sql);
		stmt.execute();
		
		sql = "use BDaula1";
		stmt = (PreparedStatement) conn.prepareStatement(sql);
		stmt.execute();
		
		sql = "create table if not exists ex01(id int , nome varchar(50));";
		stmt = (PreparedStatement) conn.prepareStatement(sql);
		stmt.execute();
		
		sql = "drop table ex01;";
		stmt = (PreparedStatement) conn.prepareStatement(sql);
		stmt.execute();
		
		sql = "drop database BDaula1;";
		stmt = (PreparedStatement) conn.prepareStatement(sql);
		stmt.execute();
	}
}
